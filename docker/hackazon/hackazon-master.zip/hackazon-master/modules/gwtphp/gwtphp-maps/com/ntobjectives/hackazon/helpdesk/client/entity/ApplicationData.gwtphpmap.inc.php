<?php
$gwtphpmap = array(
	'className' => 'com.ntobjectives.hackazon.helpdesk.client.entity.ApplicationData',
	'mappedBy' => 'com.ntobjectives.hackazon.helpdesk.client.entity.ApplicationData',
	'typeCRC' => '3860996832',
	'fields' => array (
		array(
			'name' => 'isAutorized',
			'type' => 'Z',
		),
		array(
			'name' => 'user',
			'type' => 'com.ntobjectives.hackazon.helpdesk.client.entity.User',
		)
	),
);
