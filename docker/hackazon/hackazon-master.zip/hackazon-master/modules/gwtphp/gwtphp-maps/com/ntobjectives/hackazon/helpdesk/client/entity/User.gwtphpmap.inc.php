<?php
$gwtphpmap = array(
	'className' => 'com.ntobjectives.hackazon.helpdesk.client.entity.User',
	'mappedBy' => 'com.ntobjectives.hackazon.helpdesk.client.entity.User',
	'typeCRC' => '363666882',
	'fields' => array (
		array(
			'name' => 'id',
			'type' => 'I',
		),
		array(
			'name' => 'first_name',
			'type' => 'java.lang.String',
		),
		array(
			'name' => 'username',
			'type' => 'java.lang.String',
		),
		array(
			'name' => 'last_name',
			'type' => 'java.lang.String',
		),
		array(
			'name' => 'photo',
			'type' => 'java.lang.String',
		)
	),
);
