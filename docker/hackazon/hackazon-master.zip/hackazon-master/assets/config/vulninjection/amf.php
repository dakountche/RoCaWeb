<?php
return [
    'fields' => [
    ],
    'vulnerabilities' => [
        'referrer' => [
            'enabled' => true
        ]
    ]
];