<?php
return array (
    'name' => 'default',
    'type' => 'application',
    'technology' => 'generic',
    'mapped_to' => 'default',
    'storage_role' => 'root',
    'vulnerabilities' => 
    array (
        'vuln_list' => 
        array (
            'CSRF' => 
            array (
                'enabled' => false,
            ),
        ),
    ),
);