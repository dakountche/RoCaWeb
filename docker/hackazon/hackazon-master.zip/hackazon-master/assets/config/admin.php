<?php
return array(
    'common_path' => dirname(dirname(__DIR__)) . '/assets/views/admin/common/'
);