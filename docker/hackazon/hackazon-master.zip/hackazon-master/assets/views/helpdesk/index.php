<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h1>Helpdesk</h1>
            <ol class="breadcrumb" id="breadcrumbs">
                <li><a href="/">Home</a></li>
                <li class="active">Helpdesk</li>
            </ol>
        </div>
    </div>
    <div class="section" id="helpdesk">
        Loading...
    </div>
</div>

<iframe src="javascript:''" id="__gwt_historyFrame" tabIndex='-1' style="position:absolute;width:0;height:0;border:0"></iframe>