<?php
/**
 * Created by IntelliJ IDEA.
 * User: Nikolay Chervyakov
 * Date: 30.07.2014
 * Time: 11:11
 */

// This will be added later
/* <div class="col-xs-3">
<div class="social-icons pull-right">
    <a href="#"><img alt="facebook" src="img/icon-facebook.png"></a>
    <a href="#"><img alt="twitter" src="img/icon-twitter.png"></a>
    <a href="#"><img alt="linkedin" src="img/icon-linkedin.png"></a>
    <a href="#"><img alt="rss" src="img/icon-rss.png"></a>
</div>
</div> */